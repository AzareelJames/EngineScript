const engineCode = [
    "@", "#", "©", "%", "€", "£", "→", "≙", "•",
    ";", ":", "/", "=", "-", "⌀", "℗", "°", "®",
    "$", "|", "«", "»", "+", "✕", "¥", "—", "‣",
    "¿", "¡", "„", "‗"
];

const char = [
    "A", "B", "C", "D", "E", "F", "G", "H", "I",
    "J", "K", "L", "M", "N", "O", "P", "Q", "R",
    "S", "T", "U", "V", "W", "X", "Y", "Z", ".",
    "?", "!", ",", " "
];

const x = {
    "toCode": txt => {
        // Check if is invalid

        for(let i of String(txt).toUpperCase()){
            if((engineCode.includes(i)) || (char.indexOf(i) === -1)){
                console.error(`Cannot convert ${txt} to Engine Code.`);
                return;
            }
        }

        let code = "";
        
        for(let i of String(txt).toUpperCase()){
            code += engineCode[(char.indexOf(i))];
        }
        
        return code;
    },

    "toTxt": code => {
        // Check if is invalid

        for(let i of String(code).toUpperCase()){
            if((char.includes(i)) || (engineCode.indexOf(i) === -1)){
                console.error(`Cannot convert ${code} to Text.`);
                return;
            }
        }

        let txt = "";
        
        for(let i of String(code)){
            txt += char[(engineCode.indexOf(i))];
        }
        
        return txt;
    }
}


x;