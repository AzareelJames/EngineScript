/*
Please note:
These all of the list of bad words.
Do not read!
*/

class Filter{
    constructor(txt=""){
        this.txt = String(txt.trim());

        // WARNING

        this.badWords = [
            "stupid", "ugly", "fuck", "shit", "bitch",
            "shithead", "fck", "ass", "crap", "frick",
            "hell", "omg", "oh my god", "damn", "dang",
            "damn", "cunt", "sex",
            "darn", "butt", "bum", "shame", "asshole",
            "ass hole", "shit head", "motherfucker",
            "fucker", "bullshit", "brotherfucker",
            "damnit", "dammit", "dammed", "horseshit",
            "cock", "kill", "dead", "cunt", "bugger",
            "nigger", "piss", "penis", "pigfucker",
            "porn", "pornhub", "porn hub", "prick",
            "pussy", "dumb-ass", "dumbass", "dyke",
            "fag", "faggot", "son of a bitch", "wanker",
            "dick", "idiot", "cum", "gay", "tit",
            "whore", "jerk", "wank", "fap", "horny",
            "anal", "nigga", "nigra", "slut", "sisterfucker",
            "fucking", "fucker", "twat", "twerk", "tranny",
            "cocksucker", "bastard", "bollocks", "what the fuck",
            "holy shit", "fuck you", "fck you", "you such a bitch"
        ];
    }

    clean(){
        let cleaned = this.txt.toLowerCase();

        for(let badWord of this.badWords.reverse()){
            let asterisks = "";

            for(let i=0; i<badWord.length; i++){
                asterisks += "*";
            }

            cleaned = cleaned.replaceAll(badWord, asterisks);
        }

        return cleaned.trim();
    }

    hasBadWords(){
        for(let badWord of this.badWords.reverse()){
            if(this.txt.toLowerCase().includes(badWord)){
                return true;
            }
        }

        return false;
    }
}

const x = {
    "Filter": Filter
};


x;